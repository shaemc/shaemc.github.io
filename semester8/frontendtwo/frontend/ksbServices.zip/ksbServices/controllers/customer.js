const path = require("path");

exports.getIndex = (req, res, next) => {
  res.render("index.ejs");
};

exports.getHome = (req, res, next) => {
  res.render("index.ejs");
};

exports.getAbout = (req, res, next) => {
  res.render("about.ejs");
};

exports.getServices = (req, res, next) => {
  res.render("services.ejs");
};

exports.getProjects = (req, res, next) => {
  res.render("projects.ejs");
};

exports.getContact = (req, res, next) => {
  res.render("contact.ejs");
};
