const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const { validationResult } = require("express-validator");
const Invoice = require("../models/invoices");
const Estimate = require("../models/estimate");

const mongoose = require("mongoose");
const path = require("path");

const Admin = require("../models/admin");

exports.getLogin = (req, res, next) => {
  res.render("adminView/login.ejs");
};

exports.postLogin = (req, res, next) => {
  const username = req.body.username;
  const password = req.body.password;
  console.log("Logging in:", username, "password:", password);
  Admin.findOne({ username: username })
    .then((admin) => {
      if (!admin) {
        return res.render("adminView/login.ejs");
      }
      // if user exist
      else {
        bcrypt
          .compare(password, admin.password)
          .then((doMatch) => {
            if (doMatch) {
              req.session.isLoggedIn = true;
              req.session.user = admin;
              console.log("isLoggedIn in do match: ", req.session.isLoggedIn);
              return req.session.save((err) => {
                console.log(err);
                res.redirect("adminView");
              });
            }
            return res.render("adminView/login.ejs");
          })
          .catch((err) => {
            console.log(err);
          });
      }
    })
    .catch((err) => {
      console.log(err);
      throw err;
    })
    .catch((err) => {
      console.log(err);
      throw err;
    });
};

exports.postLogout = (req, res, next) => {
  req.session.destroy((err) => {
    console.log(err);
    res.redirect("/");
  });
};

exports.getAdminView = (req, res, next) => {
  // Gets all the estimates

  Estimate.find()
    .then((estimates) => {
      const filters = req.query;
      const filteredEstimates = estimates.filter((estimate) => {
        let isValid = true;
        for (key in filters) {
          isValid = isValid && estimate[key] == filters[key];
        }
        return isValid;
      });
      Invoice.find().then((invoices) => {
        const ifilters = req.query;
        const filteredInvoices = invoices.filter((invoice) => {
          let iisValid = true;
          for (key in ifilters) {
            iisValid = iisValid && invoice[key] == ifilters[key];
          }
          return iisValid;
        });
        res.render("adminView/admin.ejs", {
          invoices: filteredInvoices,
          estimates: filteredEstimates,
        });
      });
    })
    .catch((err) => {
      console.log(err);
      throw err;
    });
};

exports.getCreateUser = (req, res, next) => {
  console.log("Create User View");
  res.render("adminView/createUser.ejs");
};

exports.postCreateAdmin = (req, res, next) => {
  const username = req.body.username;
  const password = req.body.password;
  console.log(username, password);

  if (!password) {
    //send error file
    res.render("adminView/createUser.ejs");
  }

  bcrypt
    .hash(password, 12)
    .then((hashedPassword) => {
      const admin = new Admin({
        username: username,
        password: hashedPassword,
      });
      return admin.save();
    })
    .then((result) => {
      res.render("adminView/login.ejs");
    })
    .catch((err) => {
      console.log(err);
      throw err;
    });
};

/* Invoices */
exports.postAddInvoice = (req, res, next) => {
  const firstName = req.body.firstName;
  const lastName = req.body.lastName;
  const description = req.body.description;
  const location = req.body.location;
  const dateDue = req.body.dateDue;
  const amount = req.body.amount;
  const invoiceNumber = req.body.invoiceNumber;

  const invoice = new Invoice({
    firstName: firstName,
    lastName: lastName,
    description: description,
    location: location,
    dateDue: dateDue,
    amount: amount,
    invoiceNumber: invoiceNumber,
  });
  invoice
    .save()
    .then((result) => {
      res.redirect("/admin/adminView");
    })
    .catch((err) => {
      console.log(err);
    });
};

exports.getEditInvoice = (req, res, next) => {
  const editMode = req.query.edit;
  if (!editMode) {
    return res.redirect("/");
  }

  const invId = req.params.invoiceId;
  Invoice.findById(invId)
    .then((invoice) => {
      if (!invoice) {
        return res.redirect("/");
      }
      res.render("adminView/edit-invoice", {
        pageTitle: "Edit Invoice",
        path: "/adminView/edit-invoice",
        editing: editMode,
        invoice: invoice,
      });
    })
    .catch((err) => console.log(err));
};

exports.postEditInvoice = (req, res, next) => {
  const updatedFirstName = req.body.firstName;
  const updatedLastName = req.body.lastName;
  const updatedDescription = req.body.description;
  const updatedLocation = req.body.location;
  const updatedDateDue = req.body.dateDue;
  const updatedAmount = req.body.amount;
  const updatedInvoiceNumber = req.body.invoiceNumber;
  const invId = req.body.invoiceId;

  Invoice.findById(invId)
    .then((invoice) => {
      invoice.firstName = updatedFirstName;
      invoice.lastName = updatedLastName;
      invoice.description = updatedDescription;
      invoice.location = updatedLocation;
      invoice.dateDue = updatedDateDue;
      invoice.amount = updatedAmount;
      invoice.invoiceNumber = updatedInvoiceNumber;
      return invoice.save();
    })
    .then((result) => {
      res.redirect("/admin/adminView");
    })
    .catch((err) => console.log(err));
};

exports.getDeleteInvoice = (req, res, next) => {
  const invId = req.params.invoiceId;
  Invoice.deleteOne({ _id: invId })
    .then(() => {
      res.redirect("/admin/adminView");
    })
    .catch((err) => console.log(err));
};

/* Estimates */
exports.getAddEstimate = (req, res, next) => {
  res.render("adminView/edit-estimate", {
    pageTitle: "Add Estimate",
    path: "/adminView/add-estimate",
    editing: false,
    hasError: false,
    errorMessage: null,
    validationErrors: [],
  });
};

exports.postAddEstimate = (req, res, next) => {
  const firstName = req.body.estimatesFname;
  const lastName = req.body.estimatesLname;
  const description = req.body.estimatesDescription;
  const location = req.body.estimatesLocation;
  const amount = req.body.estimatesAmount;

  const estimate = new Estimate({
    firstName: firstName,
    lastName: lastName,
    description: description,
    location: location,
    amount: amount,
  });
  estimate
    .save()
    .then((result) => {
      res.redirect("/admin/adminView");
    })
    .catch((err) => {
      const error = new Error(err);
      error.httpStatusCode = 500;
      return next(error);
    });
};

exports.getEditEstimate = (req, res, next) => {
  const editMode = req.query.edit;
  if (!editMode) {
    return res.redirect("/");
  }
  const estimateId = req.params.estimateId;
  Estimate.findById(estimateId)
    .then((estimate) => {
      if (!estimate) {
        return res.redirect("/");
      }
      res.render("adminView/edit-estimate", {
        pageTitle: "Edit Estimate",
        path: "/adminView/edit-estimate",
        editing: editMode,
        estimate: estimate,
        hasError: false,
        errorMessage: null,
        validationErrors: [],
      });
    })
    .catch((err) => {
      const error = new Error(err);
      error.httpStatusCode = 500;
      return next(error);
    });
};

exports.postEditEstimate = (req, res, next) => {
  const updatedFirstName = req.body.firstName;
  const updatedLastName = req.body.lastName;
  const updatedDescription = req.body.description;
  const updatedLocation = req.body.location;
  const updatedAmount = req.body.amount;
  const estimateId = req.body.estimateId;

  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(422).render("admin/edit-estimate", {
      pageTitle: "Edit Estimate",
      path: "/adminView/edit-estimate",
      editing: true,
      hasError: true,
      estimate: {
        firstName: updatedFirstName,
        lastName: updatedLastName,
        description: updatedDescription,
        location: updatedLocation,
        amount: updatedAmount,
      },
      errorMessage: errors.array()[0].msg,
      validationErrors: errors.array(),
    });
  }

  Estimate.findById(estimateId)
    .then((estimate) => {
      estimate.firstName = updatedFirstName;
      estimate.lastName = updatedLastName;
      estimate.description = updatedDescription;
      estimate.location = updatedLocation;
      estimate.amount = updatedAmount;
      return estimate.save().then((result) => {
        res.redirect("/admin/adminView");
      });
    })
    .catch((err) => {
      const error = new Error(err);
      error.httpStatusCode = 500;
      return next(error);
    });
};

exports.getEstimates = (req, res, next) => {
  const filters = req.query;
  if (filters) {
    const filteredEstimates = data.filter((estimate) => {
      let isValid = true;
      for (key in filters) {
        isValid = isValid && estimate[key] == filters[key];
      }
      return isValid;
    });
    res.send(filteredEstimates);
  } else {
    Estimate.find()
      .then((estimates) => {
        res.render("adminView/estimate-list", {
          prods: estimates,
          pageTitle: "All Estimates",
          path: "/estimates",
        });
      })
      .catch((err) => {
        const error = new Error(err);
        error.httpStatusCode = 500;
        return next(error);
      });
  }
};

exports.getDeleteEstimate = (req, res, next) => {
  const estimateId = req.params.estimateId;
  Estimate.deleteOne({ _id: estimateId })
    .then(() => {
      res.redirect("/admin/adminView");
    })
    .catch((err) => {
      const error = new Error(err);
      error.httpStatusCode = 500;
      return next(error);
    });
};
