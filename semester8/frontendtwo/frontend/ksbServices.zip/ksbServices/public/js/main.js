const collapsibles = document.querySelectorAll('.input__summary');

const estimatesTab = document.querySelector('.main__tabs-estimates');
const invoicesTab = document.querySelector('.main__tabs-invoices');
const invoicesView = document.querySelector('.invoices');
const estimatesView = document.querySelector('.estimates');
const invoicesContainer = document.querySelector('.invoices__container');
const newInvoiceContainer = document.querySelector('.newInvoice__container');
const estimatesContainer = document.querySelector('.estimates__container');
const newEstimatesContainer = document.querySelector(
  '.newEstimates__container'
);
const invoicesButton = document.querySelector('.invoices__button');
const newInvoicesButton = document.querySelector('.newInvoice__button');
const estimatesButton = document.querySelector('.estimates__button');
const newEstimatesButton = document.querySelector('.newEstimates__button');

collapsibles.forEach((collapsible) => {
  return collapsible.addEventListener('click', function (e) {
    const due = [...this.children][2];
    const amount = [...this.children][3];
    const content = this.nextElementSibling;
    const collapsibleArrow = [...this.children][0];
    const trashIcon = [...this.children][5];

    if (e.target != trashIcon) {
      this.classList.toggle('collapsible');
    }

    if (!content.style.maxHeight && e.target != trashIcon) {
      content.style.maxHeight = content.scrollHeight * 2 + 'px';
      content.style.padding = '0 30px 25px 59px';
      due.style.display = 'none';
      amount.style.display = 'none';

      collapsibleArrow.style.transform = 'rotate(90deg)';
    } else {
      content.style.maxHeight = null;
      content.style.padding = '0 30px 0 59px';
      due.style.display = 'block';
      amount.style.display = 'block';

      collapsibleArrow.style.transform = 'rotate(0deg)';
    }
  });
});

function showEstimatesTab() {
  invoicesView.style.display = 'none';
  estimatesView.style.display = 'grid';
  estimatesTab.classList.add('tab-selected');
  invoicesTab.classList.remove('tab-selected');
}

function showInvoicesTab() {
  invoicesView.style.display = 'grid';
  estimatesView.style.display = 'none';
  estimatesTab.classList.remove('tab-selected');
  invoicesTab.classList.add('tab-selected');
}

function showNewInvoice() {
  invoicesContainer.style.display = 'none';
  newInvoiceContainer.style.display = 'grid';
}

function showInvoices() {
  invoicesContainer.style.display = 'grid';
  newInvoiceContainer.style.display = 'none';
}

/* Practice javascript for new estimate*/

function showNewEstimate() {
  estimatesContainer.style.display = 'none';
  newEstimatesContainer.style.display = 'grid';
}

function showEstimate() {
  estimatesContainer.style.display = 'grid';
  newEstimatesContainer.style.display = 'none';
}

/* Until here */

estimatesTab.addEventListener('click', showEstimatesTab);
invoicesTab.addEventListener('click', showInvoicesTab);

invoicesButton.addEventListener('click', showNewInvoice);
newInvoicesButton.addEventListener('click', showInvoices);

estimatesButton.addEventListener('click', showNewEstimate);
newEstimatesButton.addEventListener('click', showEstimate);

