export default class Partials {
  constructor(){};

  async loadHeaderFooter() {
      const header = document.getElementById("header");
      const footer = document.getElementById("footer");
      const headerTemplate = await this.loadTemplate("../html/header.html");
      const footerTemplate = await this.loadTemplate("../html/footer.html");
    
      this.renderWithTemplate(headerTemplate, header);
      this.renderWithTemplate(footerTemplate, footer);

      this.hamButton();
  }

  convertToText(res) {
      if (res.ok) {
        return res.text();
      } else {
        throw new Error("Bad Response");
      }
    }

  async loadTemplate(path) {
      const html = await fetch(path).then(this.convertToText);
      const template = document.createElement("template");
      template.innerHTML = html;
      return template;
    }

  renderWithTemplate(template, parentElement, data, callback) {
  let clone = template.content.cloneNode(true);

  if (callback) {
      clone = callback(clone, data);
  }

  parentElement.appendChild(clone);
  }

  hamButton() {
      const navLinks = document.querySelector('.nav__links');
      const hero = document.querySelector('.hero');
      if (navLinks.style.display === 'flex') {
        navLinks.style.display = 'none';
        hero.style.marginTop = '0px';
    
      } else {
        navLinks.style.display = 'flex';
        if(window.innerWidth < 750) {
          hero.style.marginTop = '210px';
        }
      }
      const icon = document.querySelector('.nav__icon');
      icon.addEventListener('click', this.hamButton);
  }
}