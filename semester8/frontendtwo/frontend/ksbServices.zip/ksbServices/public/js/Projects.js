export default class Projects {
  constructor(container, jsonFile) {
    this.container = container;
    this.jsonFile = jsonFile;
  }

  async getProjects() {
    const data = await fetch(this.jsonFile);
    const results = await data.json();

    results.map((project, index) => {
      const html = `<div class="project__card">
          <img src="assets/gallery/${project.images[0]}.jpg" alt="${
        project.name
      }" />

          <div class="project__info">
            <h4 class="project__place">${project.name}</h4>

            <p class="project__description">
              ${project.description}
            </p>

            <a href="/projects#project${
              index + 1
            }" class="project__link">View Project</a>
          </div>
        </div>`;

      this.container.innerHTML += html;
    });
  }

  async getGallery() {
    const data = await fetch(this.jsonFile);
    const results = await data.json();

    results.map((project, index) => {
      const html = `<section id='project${index}' class="gallery__section">
      <h2>${project.name}</h2>

      <div class="gallery__images">
        ${project.images
          .map(
            (image) =>
              `<img src="/assets/gallery/${image}.jpg" alt="${image}" />`
          )
          .join('')}
      </div>
    </section>`;

      this.container.innerHTML += html;
    });
  }
}
