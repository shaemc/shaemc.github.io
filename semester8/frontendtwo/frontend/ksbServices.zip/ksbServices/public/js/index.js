import Partials from '/js/partials.js';
import Projects from '/js/Projects.js';

const projectsContainer = document.querySelector('.projects__container');
const jsonFile = '/json/projects.json';

const partials = new Partials();
partials.loadHeaderFooter();

const projects = new Projects(projectsContainer, jsonFile);
projects.getProjects();
