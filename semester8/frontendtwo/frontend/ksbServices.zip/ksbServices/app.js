const path = require("path");

const express = require("express");
const mongoose = require("mongoose");
const PORT = process.env.PORT || 3000;
const session = require("express-session");
const MONGODBKSB = require("connect-mongodb-session")(session);
const csrf = require("csurf");
const flash = require("connect-flash");

//Database
const MONGODB_URI =
  "mongodb+srv://kathy_hansen:1Fu0YzGrH28d0XKG@ksbservices.s6k6z.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";

const app = express();
//Needed to initialize session
const store = new MONGODBKSB({
  uri: MONGODB_URI,
  collection: "sessions",
});
const csrfProtection = csrf();

app.set("view engine", "ejs");
app.set("views", "views");

//connect to the routes folder
const adminRoutes = require("./routes/admin");
const mainRoutes = require("./routes/customer");

app.use(express.urlencoded({ extended: false }));

app.use(
  session({
    secret: "my secret",
    resave: false,
    saveUninitialized: false,
    store: store,
  })
);

app.use(csrfProtection);

//Sets isAuthenticated and csrfToken for every request executed
app.use((req, res, next) => {
  res.locals.isAuthenticated = req.session.isLoggedIn;
  res.locals.csrfToken = req.csrfToken();
  next();
});

app.use(express.static(path.join(__dirname, "public")));

app.use("/admin", adminRoutes);
app.use(mainRoutes);

const MONGODB_URL =
  process.env.MONGODB_URL ||
  "mongodb+srv://kathy_hansen:1Fu0YzGrH28d0XKG@ksbservices.s6k6z.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";

const cors = require("cors");
const corsOptions = {
  origin: "https://ksb-services.herokuapp.com/",
  optionsSuccessStatus: 200,
};
app.use(cors(corsOptions));

const options = {
  useUnifiedTopology: true,
  useNewUrlParser: true,
  family: 4,
};

mongoose
  .connect(MONGODB_URI)
  .then((result) => {
    app.listen(PORT);
  })
  .catch((err) => {
    console.log(err);
  });
