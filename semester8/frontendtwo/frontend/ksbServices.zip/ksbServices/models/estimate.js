const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const estimateSchema = new Schema({
  firstName: {
    type: String,
    required: true,
  },
  lastName: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  location: {
    type: String,
    required: true,
  },
  amount: {
    type: Number,
    required: true,
  }
});

module.exports = mongoose.model("Estimate", estimateSchema);
