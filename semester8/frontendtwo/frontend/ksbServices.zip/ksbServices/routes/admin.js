const path = require("path");
const express = require("express");
const isAuth = require("../middleware/is-auth");

const router = express.Router();

const adminController = require("../controllers/admin");

router.get("/login", adminController.getLogin);

router.get("/createUser", adminController.getCreateUser);
router.post("/postCreateUser", adminController.postCreateAdmin);
router.get("/logout", adminController.postLogout);
router.post("/login", adminController.postLogin);

//Routes that need authentication

router.get("/adminView", isAuth, adminController.getAdminView);
router.post("/postInvoice", isAuth, adminController.postAddInvoice);

/* Estimates Routes */
router.get("/add-estimate", isAuth, adminController.getAddEstimate);
router.post("/postEstimate", isAuth, adminController.postAddEstimate);
router.get(
  "/edit-estimate/:estimateId",
  isAuth,
  adminController.getEditEstimate
);
router.post("/post/edit-estimate", isAuth, adminController.postEditEstimate);
router.get(
  "/deleteEstimate/:estimateId",
  isAuth,
  adminController.getDeleteEstimate
);

router.get("/edit-invoice/:invoiceId", isAuth, adminController.getEditInvoice);
router.post("/post/edit-invoice", isAuth, adminController.postEditInvoice);
router.get(
  "/deleteInvoice/:invoiceId",
  isAuth,
  adminController.getDeleteInvoice
);

module.exports = router;
