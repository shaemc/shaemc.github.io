const path = require("path");
const express = require("express");

const customerController = require("../controllers/customer");

const router = express.Router();

router.get("/home", customerController.getHome);
router.get("/about", customerController.getAbout);
router.get("/services", customerController.getServices);
router.get("/projects", customerController.getProjects);
router.get("/contact", customerController.getContact);

router.get("/", customerController.getIndex);
module.exports = router;
